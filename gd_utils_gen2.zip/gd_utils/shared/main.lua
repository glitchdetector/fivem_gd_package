
Citizen.CreateThread(function()
    print("gd_util/shared/main.lua init")
--    while true do
--        Citizen.Wait(5)  
--    end
end)