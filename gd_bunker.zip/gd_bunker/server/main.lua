--[[local Proxy = require("resources/vRP/lib/Proxy")
local Tunnel = require("resources/vRP/lib/Tunnel")

vRP = Proxy.getInterface("vRP")
vRPClient = Tunnel.getInterface("vRP","gd_bunker")

local bunkerEnterances = {
    
}
local bunkerPosition = {
    
}

local playerEntry = {}]]