------------------
-- CONFIG START --
------------------

-- Messages
local startText = "Press ~g~E ~w~to start a ~g~Bus Route ~w~from ~g~%s~w~"
local pickupText = "Press ~g~E ~w~to pick up ~g~%s ~w~from ~g~%s~w~"
local invalidVehicleText = "You need a ~g~BUS ~w~to do this"
local engineRunningText = "Fully ~r~STOP ~w~before boarding / deboarding"

local vehicleFullMessage = "Your vehicle is ~r~FULL~w~"
local capacityMessage = "Current ~g~%s ~w~[~y~%i~w~/~y~%i~w~]"
local continueMessage = "Continue ~g~%s ~w~route [~y~%i~w~/~y~%i~w~]"

local startRouteMessage = "Complete the ~g~%s ~w~route"
local jobDoneMessage = "Finished ~g~%s ~w~route"

-- Methods
local engineNeedsToBeOff = true 

-- Map Blips
local job_blips = {
    {name = "Bus Service", x = 470.0, y = -625.0},
    {name = "Bus Service", x = 1955.0, y = 3771.0},
    {name = "Bus Service", x = -362.9, y = 6069.8},
}

-- Locations
local ls_routes = {
    {
        {name = "LSIA Terminal 2", 		x = -1048.877930, y = -2540.111572, z = 12.505210},
        {name = "Maze Bank Arena", 		x = -307.695801, y = -1844.940430, z = 23.845625},
        {name = "Strawberry Avenue", 	x = -43.776791, y = -1648.477661, z = 28.033178},
        {name = "Carson Avenue", 		x = 50.928295, y = -1536.593506, z = 28.018265},
        {name = "Adam's Apple Blv", 	x = 98.416206, y = -1055.010620, z = 28.118307},
        {name = "San Andreas Avenue", 	x = 115.008423, y = -784.036377, z = 30.126572},
        {name = "San Vitus Blvd", 		x = -256.629272, y = -330.119690, z = 28.699272},
        {name = "Boulevard Del Perro", 	x = -490.618530, y = 20.407391, z = 43.791027},
        {name = "Strangeways Drive", 	x = -693.450562, y = -5.167409, z = 37.019169},
        {name = "Mad Wayne Thunder Dr", x = -931.669128, y = -126.633087, z = 36.415554},
        {name = "Marathon Avenue", 		x = -1047.878540, y = -389.459473, z = 36.419994},
        {name = "Rockford Hills", 		x = -679.639771, y = -376.881226, z = 33.043865},
        {name = "Ginger Street", 		x = -652.388367, y = -607.065369, z = 32.059444},
        {name = "Vespucci Blvd", 		x = -558.416321, y = -846.186951, z = 26.312037},
        {name = "La Puerta Fwy", 		x = -250.537796, y = -883.167053, z = 29.415934},
        {name = "Innocence Blvd", 		x = -302.779999, y = -1476.822632, z = 29.369450},
    }
}

local sandy_routes = {
    {
        {name = "Otto's Auto Parts",            x = 1934.254883, y = 3717.046631, z = 31.419857},
        {name = "Sandy Shores EMS Center",      x = 1852.423828, y = 3669.115479, z = 32.922707},
        {name = "Sandy Shores Fire Station",    x = 1708.511719, y = 3584.693359, z = 34.450268},
        {name = "Sandy Shores Motel",           x = 1614.452759, y = 3599.380859, z = 34.141155},
        {name = "Liquor Ace",                   x = 1404.076904, y = 3596.956055, z = 33.878101},
        {name = "Outskirt Liquor Marker",       x = 914.946106, y = 3611.223389, z = 31.777626},
        {name = "Zancudo River",                x = 323.576447, y = 3573.897217, z = 32.566010},
        {name = "Outskirts Market",             x = 461.751740, y = 3574.130371, z = 32.234318},
        {name = "Outskirts Junk Yard",          x = 1276.636353, y = 3636.295166, z = 32.254848},
        {name = "The Boat House",               x = 1537.832153, y = 3769.875000, z = 33.045795},
        {name = "Sandy Shores Ammu-Nation",     x = 1718.996094, y = 3759.021729, z = 33.037987},
        {name = "Sandy Shores St.",             x = 1700.300049, y = 3885.505859, z = 33.810108},
        {name = "Sandy Shores Grocery Store",   x = 1963.717896, y = 3854.875732, z = 30.984299},
        {name = "Sandy Shores Gas Station",     x = 1992.588745, y = 3761.645264, z = 31.175697},
    },
    {
        {name = "Sandy Shores Gas Station",     x = 1991.923950, y = 3760.260986, z = 31.173931},
        {name = "Grapeseed Auto Repairs",       x = 2503.481445, y = 4102.588867, z = 37.249912},
        {name = "Grapeseed Cattle Farm",        x = 2547.243652, y = 4692.306152, z = 32.609898},
        {name = "Grapeseed Substation",         x = 2575.273193, y = 5081.580566, z = 43.642788},
        {name = "Chiliad Trail",                x = 2467.405029, y = 5120.727051, z = 45.637135},
        {name = "Grapeseed Farms",              x = 2285.321045, y = 5032.166016, z = 42.794975},
        {name = "Union Grain",                  x = 2079.138184, y = 5010.342773, z = 39.909019},
        {name = "Grapeseed Gas Station",        x = 1680.080811, y = 4936.329102, z = 41.101730},
        {name = "Grapeseed Centre",             x = 1665.092651, y = 4823.284180, z = 40.986298},
        {name = "Grapeseed Centre",             x = 1690.948608, y = 4683.540527, z = 41.977924},
        {name = "Alamo Fruit Market",           x = 1793.002075, y = 4578.837891, z = 35.839657},
        {name = "McKenzie Field",               x = 2101.956055, y = 4748.267090, z = 40.160950},
        {name = "Grapeseed Fruit Vendor",       x = 2479.939209, y = 4446.204102, z = 34.371422},
        {name = "Grapeseed Liquor Market",      x = 2468.885986, y = 4059.290283, z = 36.595963},
        {name = "Outskirts Underpass",          x = 2314.218262, y = 3840.397217, z = 33.808651},
        {name = "Sandy Shores Substation",      x = 2069.545166, y = 3714.340088, z = 31.904259},
    }
}

local paleto_routes = {
    {
        {name = "Paleto Bay Market", x = -389.286926, y = 6057.842285, z = 30.496717},
        {name = "Paleto Bay Bus Stop", x = -331.934662, y = 6192.689453, z = 30.266617},
        {name = "The Hen House", x = -326.344421, y = 6261.967285, z = 30.369061},
        {name = "South Seas Apartments", x = -173.986389, y = 6455.390137, z = 29.879629},
        {name = "Paleto Bay Centre", x = -73.135674, y = 6453.126465, z = 30.274168},
        {name = "Paleto Bay Truck Stop", x = 137.652603, y = 6636.105957, z = 30.627174},
        {name = "Zancudo Grain Growers", x = 425.742310, y = 6555.231934, z = 26.183887},
        {name = "Outskirts Gas Station", x = 1701.486328, y = 6410.923340, z = 31.959030},
        {name = "Up-n-Atom Diner", x = 1584.058472, y = 6440.204102, z = 23.964773},
        {name = "Paleto Bay Warehouses", x = 52.838566, y = 6447.492188, z = 30.351645},
        {name = "Cluckin' Bell Factory", x = -21.842253, y = 6267.696777, z = 30.215376},
        {name = "Paleto Bay Hwy Stop", x = -215.601974, y = 6172.683105, z = 30.216635},
        {name = "Paleto Bay Ammu-Nation", x = -318.693695, y = 6071.897949, z = 30.260986},
    }
}

-- Job Start markers
local job_starts = {
    {name = "Los Santos Bus Service", x = 460.0, y = -625.0, z = 27.5, tier = 1, routes = ls_routes},
    {name = "Sandy Shores Bus Service", x = 1955.0, y = 3771.0, z = 31.2, tier = 1, routes = sandy_routes},
    {name = "Paleto Bay Bus Service", x = -362.9, y = 6069.8, z = 30.5, tier = 1, routes = paleto_routes},
}

-- Vehicles plus tiers
local job_vehicles = {
    {name = "BUS", tier = 1},
    {name = "RENTALBUS", tier = 1},
    {name = "AIRBUS", tier = 2},
    {name = "COACH", tier = 3},
}

-- Localized names for peds
local ped_names = {
    ["default"] = "Passengers",
}

-- Payment multiplier for ped
local ped_payment = {
    ["default"] = 1.0,
}

local ped_models = {
    "A_M_Y_GenStreet_01",
    "A_M_M_Business_01",
    "A_M_Y_Hiker_01",
}
----------------
-- CONFIG END --
----------------

--[[local debugMarkers = {}

RegisterNetEvent("gd:pos")
AddEventHandler("gd:pos", function(msg)
    local pos = GetEntityCoords(GetPlayerPed(-1))
    TriggerServerEvent("gd:pos", msg, {x = pos.x, y = pos.y, z = pos.z - 1})
    table.insert(debugMarkers, {name = "debug", x = pos.x, y = pos.y, z = pos.z - 1})
end)]]

RegisterNetEvent("gd_jobs_bus:startJob")
AddEventHandler("gd_jobs_bus:startJob",
    function(start, tier)
        startJob(start, tier)
    end
)

function getRandomPedModel()
    local mod = ped_models[math.random(#ped_models)]
    return mod
end

function drawMarker(x,y,z)
    DrawMarker(1, x, y, z, 0,0,0,0,0,0,5.0,5.0,2.0,0,155,255,200,0,0,0,0)
end

local current_job = {}

function setNewDestination(pos)
--    if DoesBlipExist(current_job.blip) then RemoveBlip(current_job.blip) end
--    current_job.blip = AddBlipForCoord(pos.x, pos.y, pos.z)
--    setBlipName(current_job.blip, pos.name)
--    SetBlipRoute(current_job.blip, true)
end

function setBlipName(blip, name)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(name)
    EndTextCommandSetBlipName(blip) 
end

function getRandomLocation(tier)
    local loc = 0
    repeat
        loc = job_pickups[math.random(#job_pickups)]
    until loc.tier <= tier
    return loc
end
    
function generateBlipsFromRoute(route)
    for k,v in next, route do
        local blip = AddBlipForCoord(v.x, v.y, 0)
        SetBlipScale(blip, 0.75)
        SetBlipSprite(blip, 513)
        SetBlipColour(blip, 57)
        setBlipName(blip, "(Route) " .. v.name)
        v.blip = blip
    end
end

function table.clone(org)
  return {table.unpack(org)}
end

function startJob(start, tier)
    if isOnJob() then
        cancelJob()
    end
    current_job.previous = start
    current_job.start = start
    current_job.route = start.routes[math.random(#start.routes)]
    current_job.total_stops = #current_job.route
    generateBlipsFromRoute(current_job.route)
    current_job.cargo = {name = ped_names["default"], pay = ped_payment["default"]}
    current_job.tier = tier
    current_job.fares = 0
    current_job.peds = {}

    setNewDestination(current_job.marker)
    drawMessage(string.format(startRouteMessage, current_job.cargo.name))

end

function createPedsThatEnterVehicle(number)
    local peds = {}
    local veh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local pos = GetEntityCoords(veh)
    local _model = getRandomPedModel()
    local model = GetHashKey(_model)
    RequestModel(model)
    while not HasModelLoaded(model) do Citizen.Wait(1) end
    
    local _peds = 0
    
    print(number)
    
    for _i = 1, GetVehicleMaxNumberOfPassengers(veh) do
        print("_i: ".._i)
        if _peds >= number then break end
        if not DoesEntityExist(GetPedInVehicleSeat(veh, _i)) then 
            print("ped")
            local ped = CreatePed(4, model, pos.x + GetEntityForwardX(veh) * (6 + _peds), pos.y + GetEntityForwardY(veh) * (6 + _peds), pos.z, 0, true, 0)
            TaskEnterVehicle(ped, veh, 1000, _i, 1.0, 3, 0)
            table.insert(peds, ped)
            _peds = _peds + 1
        end
    end  
    return peds
end

function makePedsLeaveTheVehicle(number)
    local _i = 0
    for _i = 1, number do
        if next(current_job.peds) ~= nil then
            local ped = current_job.peds[math.random(#current_job.peds)]
            if DoesEntityExist(ped) then
                TaskLeaveAnyVehicle(ped, 0, 0)
                SetTimeout(3000, function()
                    RemovePedElegantly(ped) 
                end)
            end
        end
    end
end

function pickupJob(id)
    local p = table.remove(current_job.route, id)
    local supply = math.random(p.supply or 3)
    local demand = math.random(p.demand or 5)
    
    print(supply)
    print(demand)
    
    makePedsLeaveTheVehicle(demand)
    RemoveBlip(p.blip)
    p.blip = nil
    
    local veh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local peds = createPedsThatEnterVehicle(supply)    
    local newpeds = 0
    if next(peds) ~= nil then
        for k,v in next, peds do
            newpeds = newpeds + 1
            table.insert(current_job.peds, v)
        end
    end
    
    current_job.fares = current_job.fares + newpeds
    
    TriggerServerEvent("gd_jobs_bus:pickupJob", newpeds, current_job.cargo.pay, current_job.tier)
    if (#current_job.route > 0) then
        drawMessage(string.format(continueMessage, current_job.cargo.name, current_job.total_stops - #current_job.route, current_job.total_stops))
    else
        deliverJob()
    end
end

function deliverJob()    
    TriggerServerEvent("gd_jobs_bus:finishJob", current_job.fares, current_job.cargo.pay, current_job.tier)
    drawMessage(string.format(jobDoneMessage, current_job.cargo.name))
    cancelJob()
end

function isOnJob()
    return (next(current_job) ~= nil)
end

function cancelJob()
    -- Remove all blips
    if next(current_job.route) ~= nil then
        for k,v in next, current_job.route do
            if DoesBlipExist(v.blip) then
                RemoveBlip(v.blip)
            end
        end
    end
    
    -- Make peds exit vehicle and fuck off
    if next(current_job.peds) ~= nil then
        for k,v in next, current_job.peds do
            if DoesEntityExist(v) then
                TaskLeaveAnyVehicle(v, 0, 0)
                SetTimeout(3000, function()
                    RemovePedElegantly(v) 
                end)
            end
        end
    end
    current_job = {}
end

function drawText(text)
    Citizen.InvokeNative(0xB87A37EEB7FAA67D,"STRING")
    AddTextComponentString(text)
    Citizen.InvokeNative(0x9D77056A530643F6, 500, true)
end

function drawMessage(text)
    Citizen.InvokeNative(0xB87A37EEB7FAA67D,"STRING")
    AddTextComponentString(text)
    Citizen.InvokeNative(0x9D77056A530643F6, 20000, false)
end

function isInValidVehicle()
    local veh = GetVehiclePedIsIn(GetPlayerPed(-1), false)
    local validVehicle = false
    for k,v in next, job_vehicles do
        if GetEntityModel(veh) == GetHashKey(v.name) then validVehicle = true break end 
    end
    return validVehicle
end

function promptJob(location, tier)
    local validVehicle = isInValidVehicle()
    if validVehicle then
        drawText(string.format(startText, location.name))         
        if isEPressed() then
            TriggerServerEvent("gd_jobs_bus:tryStartJob", location, tier) 
            return
        end
    else
        drawText(invalidVehicleText) 
    end
end

function nearMarker(x, y, z)
    local p = GetEntityCoords(GetPlayerPed(-1))
    local zDist = math.abs(z - p.z)
    return (GetDistanceBetweenCoords(x, y, z, p.x, p.y, p.z) < 7 and zDist < 4) 
end

function isEPressed()
    return IsControlJustPressed(0, 38)
end

function getCurrentTier()
    local tier = 0
    local veh = GetVehiclePedIsIn(GetPlayerPed(-1))
    if veh then
        for k,v in next, job_vehicles do
             if GetEntityModel(veh) == GetHashKey(v.name) then tier = v.tier break end 
        end
    end
    return tier
end

Citizen.CreateThread(function()
    for k,v in next, job_blips do 
        local blip = AddBlipForCoord(v.x, v.y, 0) 
        SetBlipSprite(blip, 513)
        SetBlipColour(blip, 38)
        SetBlipAsShortRange(blip, true)
        setBlipName(blip, v.name)
    end
    while true do
        Citizen.Wait(1)
        if not isOnJob() then
            -- NOT ON JOB
            local p = GetEntityCoords(GetPlayerPed(-1))
            for k,v in next, job_starts do 
                drawMarker(v.x, v.y, v.z)    
                if nearMarker(v.x, v.y, v.z) then
                    promptJob(v, getCurrentTier())
                end
            end
            --[[for k,v in next, job_pickups do 
                drawMarker(v.x, v.y, v.z)    
            end
            for k,v in next, debugMarkers do 
                drawMarker(v.x, v.y, v.z)    
            end]]
        else
            -- ON JOB
            for k,v in next, current_job.route do
                local marker = v
                local p = GetEntityCoords(GetPlayerPed(-1))
                local veh = GetVehiclePedIsIn(GetPlayerPed(-1))
                drawMarker(marker.x, marker.y, marker.z)
                if nearMarker(marker.x, marker.y, marker.z) and isInValidVehicle() and getCurrentTier() >= current_job.tier then
                    if GetEntitySpeed(veh) > 0.1 and engineNeedsToBeOff then
                        drawText(string.format(engineRunningText))
                    else
                        drawText(string.format(pickupText, current_job.cargo.name, v.name))
                        if isEPressed() then
                            pickupJob(k)
                        end
                    end
                end
            end
        end
    end
end)