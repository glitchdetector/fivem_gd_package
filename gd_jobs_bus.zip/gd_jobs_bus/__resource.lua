description 'Bus Jobs by GlitchDetector'

-- Server
server_scripts { 
    'server/main.lua'
}

-- Client
client_scripts {
	'client/main.lua'
}