client_script 'client/atc.lua'
client_script 'client/menu.lua'
--client_script 'client/pedTasking.lua'
client_script 'client/airportmarkers.lua'

server_script 'server/atc.lua'