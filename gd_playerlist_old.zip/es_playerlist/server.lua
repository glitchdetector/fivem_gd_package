local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")

local blank = {x=40,y=39}
local cache = {time = 0, data = {}}
-- http://ask.hiof.no/~vegardbe/privat/fivem/emojis.html
-- prefix, suffix, title, color, namecolor, hidden, sort, timer
local rank_special = {
    ["bank"] =              {suffix = {x=19,y=30}, color = "forestgreen", title = "Money Transport"},
    ["busdriver"] =         {suffix = {x=36,y=21}, color = "cornflowerblue", title = "Bus Driver"},
    ["citizen"] =           {},
    ["emergency"] =         {suffix = {x=36,y=22}, color = "tomato", title = "EMS"},
    ["farmer"] =            {suffix = {x=36,y=33}, color = "chocolate", title = "Farmer",
        levelnames = {"farming", "farming"},
        levels = {
            [10] = {title = "Skilled Farmer"},
            [20] = {title = "Professional Farmer", namecolor = "chocolate"},
        }},
    ["firefighter"] =       {suffix = {x=9,y=32}, color = "red", title = "Firefighter"},
    ["garbage"] =           {suffix = {x=32,y=38}, color = "saddlebrown", title = "Garbage"},
    ["guard"] =             {suffix = {x=32,y=20}, color = "darkslateblue", title = "Prison Transport"},
    ["helicopterpilot"] =   {suffix = {x=36,y=6}, color = "white", title = "Helicopter Pilot"},
    ["hunter"] =            {suffix = {x=25,y=12}, color = "darkolivegreen", title = "Hunter",
        levelnames = {"hunting", "hunting"},
        levels = {
            [5] = {title = "Skilled Hunter"},
            [10] = {title = "Professional Hunter", namecolor = "darkolivegreen"},
        }},
    ["mechanic"] =          {suffix = {x=11,y=32}, color = "chocolate", title = "Mechanic"},
    ["pilot"] =             {suffix = {x=2,y=37}, color = "darkcyan", title = "Pilot",
        levelnames = {"piloting", "piloting"},
        levels = {
            [5] = {title = "Skilled Pilot"},
            [10] = {title = "Professional Pilot", namecolor = "darkcyan"},
        }},
    ["pizza"] =             {suffix = {x=6,y=19}, color = "goldenrod", title = "Pizza Delivery"},
    ["police"] =            {suffix = {x=36,y=25}, color = "blue", title = "Police Rookie",
        levelnames = {"police", "police"},
        levels = {
            [2] = {title = "Police Deputy"},
            [3] = {title = "Police Sergeant"},
            [5] = {title = "Police Lieutenant"},
            [7] = {title = "Police Colonel"},
            [10] = {title = "Police Superintendent", namecolor = "blue"},
        }},
    ["taxi"] =              {suffix = {x=36,y=26}, color = "gold", title = "Taxi"},
    ["trucker"] =           {suffix = {x=36,y=32}, color = "darkgreen", title = "Trucker",
        levelnames = {"trucking", "trucking"},
        levels = {
            [5] = {title = "Skilled Trucker"},
            [10] = {title = "Professional Trucker", namecolor = "darkgreen"},
        }},
    
    ["user"] =              {},
    ["staff"] =             {},
    ["support"] =           {},
    ["mod"] =               {},
    ["admin"] =             {},
    ["headadmin"] =         {},
    ["superadmin"] =        {},
    
    ["hidden"] =            {hidden = true}, 
    ["kicked"] =            {prefix = {x=40,y=2}}, 
    ["muted"] =             {prefix = {x=32,y=11}, title = "Muted", color = "darkgray", namecolor = "darkgray"}, 
    ["underage"] =          {prefix = {x=2,y=32}, namecolor = "tomato"}, 
    ["champion"] =          {suffix = {x=3,y=22}, title = "Event Champion", color = "gold", namecolor = "gold"}, 
}

local overrides = {
    [2] =                   {prefix = {x=0,y=32}},
    [3] =                   {prefix = {x=25,y=4}, namecolor = "gainsboro"},
    [6] =                   {prefix = {x=24,y=33}},
    [7] =                   {prefix = {x=24,y=22}},
    [9] =                   {prefix = {x=6,y=38}},
    [17] =                  {prefix = {x=2,y=32}},
    [576] =                 {prefix = {x=28,y=9}},
    [4757] =                {prefix = {x=24,y=16}},
    [5885] =                {prefix = {x=24,y=33}},
}

local fakeplayerlist = false
local fakeplayerlistsize = 35
local fakenames = {
    "Default Danny",
    "isponsorcontent csgo.com",
    "my name jeff",
    "PICKLE RICK XD",
    "jumpdragon",
    "foxxy333",
    "lombankwest22",
    "RedBamboozle",
    "hunter2",
    "Richard El",
    "RC-23 | Layton",
    "K9 Unit - Spencer Pien",
    ":D",
    "RektPonyMan",
    "Fuzzy Butt Fox",
    "RedditUser",
    "9gag.com",
    "tommytimmyboy",
    "Franker [GER]",
    "phoon",
    "pLaYErLiSt gUd?",
}

local connections = 0
local login_time = {}
local total_time = {}
AddEventHandler("vRP:playerJoin", function(user_id, user, name, last_login)
    connections = connections + 1
    login_time[user_id] = os.clock()
    total_time[user_id] = 0
    local function cb(data)
        if data == nil or data == "" then data = 0 end
        total_time[user_id] = tonumber(data)
    end
    vRP.getUData({user_id, "playtime", cb})
end)

AddEventHandler("vRP:playerLeave", function(user_id, user)
    local totaltime = (os.clock() - login_time[user_id]) + total_time[user_id]
    if totaltime > 0 then 
        vRP.setUData({user_id, "playtime", totaltime})
    end
end)

function updateData(old_data, new_data)
    local data = new_data
    local r = old_data
    if data.id then
        r.id = data.id
    end
    if data.name then
        r.name = data.name
    end
    if data.title then
        r.title = data.title
    end
    if data.color then
        r.color = data.color
    end
    if data.namecolor then
        r.namecolor = data.namecolor
    end
    if data.prefix then
        r.prefix = data.prefix
    end
    if data.usericon then
        r.usericon = data.usericon
    end
    if data.suffix then
        r.suffix = data.suffix
    end
    if data.timer then
        r.timer = data.timer
    end
    if data.hidden then
        r.hidden = tonumber(data.hidden)
    end
    if data.sort then
        r.sort = tonumber(data.sort)
    end
    return r
end

RegisterServerEvent("gd_playerlist:askOpen")
AddEventHandler("gd_playerlist:askOpen", function()
    local source = source
    local playerList = {}
    if (os.clock() - cache.time > 20) then -- 20 second cache to reduce load time
        -- Need new cache
        local users = vRP.getUsers()
        for user_id, user in next, users do
            if tostring(GetPlayerName(user)) ~= 'nil' then
                if not login_time[user_id] then login_time[user_id] = os.clock() end -- set their fucking time if it isnt set
                local logintime = os.clock() - login_time[user_id]
                local totaltime = logintime + total_time[user_id]
                local color = "white"
                local namecolor = "white"
                local rank_color = "white"
                local title = ""
                local prefix = {x=40,y=39}
                local suffix = {x=40,y=39}
                local timer = ""
                local id = user_id
                local hidden = false
                local name = GetPlayerName(user)
                local sort = logintime
                local data = {}
                for group, group_data in next, rank_special do
                    if vRP.hasGroup({user_id, group}) then
                        -- Assign data from group (job, rank etc)
                        data = updateData(data, group_data)
                            
                        -- Assign extra data from group based on levels
                        if group_data.levelnames then
                            local category = group_data.levelnames[1]
                            local skillname = group_data.levelnames[2]
                            local skill = category .. "." .. skillname
                            for level, leveldata in next, group_data.levels do
                                if vRP.hasPermission({user_id, "@" .. skill .. ".>" .. (level - 1)}) then
                                    data = updateData(data, leveldata)
                                end
                            end
                        end
                    end
                end
                for key, override_data in next, overrides do
                    if user_id == key then
                        data = updateData(data, override_data)
                    end
                end
                    
                if data.id then
                    id = data.id
                end
                if data.name then
                    name = data.name
                end
                if data.title then
                    title = data.title
                end
                if data.color then
                    color = data.color
                end
                if data.namecolor then
                    namecolor = data.namecolor
                end
                if data.prefix then
                    prefix = data.prefix
                end
                if data.usericon then
                    usericon = data.usericon
                end
                if data.suffix then
                    suffix = data.suffix
                end
                if data.timer then
                    timer = data.timer
                end
                if data.hidden then
                    hidden = tonumber(data.hidden)
                end
                if data.sort then
                    sort = tonumber(data.sort)
                end
                    
                local icon = GenerateCSSPosition(prefix)
                local jobicon = GenerateCSSPosition(suffix)

                local time = GetSexyTime(logintime)
                local timetotal = GetSexyTime(totaltime)
                local uptime = GetSexyTime(os.clock())
                if timer ~= "" then
                    time = timer
                end
                if (not hidden) then 
                    table.insert(playerList, {prefix = "", name = name, id = id, player = user, title = title, color = color, namecolor = namecolor, time = time, uptime = uptime, connections = connections, sort = sort, icon = icon, jobicon = jobicon, totaltime = timetotal})
                end
            end
        end
        while #playerList < fakeplayerlistsize and fakeplayerlist do
            for k,v in next, rank_special do
                local time = math.random(4*60*60)
                table.insert(playerList, {prefix = v.prefix or '', name = fakenames[math.random(#fakenames)], id = math.floor(math.random(23000)), player = 0, title = v.title or '', color = v.color or 'white', namecolor = v.namecolor or 'white', time = GetSexyTime(time), uptime = GetSexyTime(1*24*60*60 + math.random(24*60*60)), sort = -time, connections = connections, icon = GenerateCSSPosition(v.prefix or {x=40,y=39}), jobicon = GenerateCSSPosition(v.suffix or {x=40,y=39})})
                if #playerList >= fakeplayerlistsize then break end
            end
        end
        table.sort(playerList, function(a,b)
            return (a.sort or 0) > (b.sort or 0)
        end)
        cache = {time = os.clock(), data = playerList}
    else
        -- Load cache instead
        playerList = cache.data            
    end
--    print("sending open request")
    TriggerClientEvent("gd_playerlist:open", source, playerList)
end)

function set(s,t)
    local source = s
    local user_id = vRP.getUserId({source})
    if user_id ~= nil then
        vRP.prompt({source, "uid", "0", function(player,result)
            local sel_id = tonumber(result)
            if sel_id then
                vRP.prompt({source, t, "", function(player,result)
                    sel_pref = result
                    if not overrides[sel_id] then overrides[sel_id] = {} end
                    if sel_pref == "" then sel_pref = nil end
                    overrides[sel_id][t] = sel_pref
                end})   
            end
        end})
    end
end
function setIcon(s,t) -- user s prompted to change t icon for any user
    local source = s
    local user_id = vRP.getUserId({source})
    if user_id ~= nil then
        vRP.prompt({source, "uid", "0", function(player,result)
            local sel_id = tonumber(result)
            if sel_id then
                vRP.prompt({source, "x", "", function(player,result)
                    local sel_x = tonumber(result)
                    if not overrides[sel_id] then overrides[sel_id] = {} end
                    if sel_x == nil or result == "" then sel_x = 40 end
                    vRP.prompt({source, "y", "", function(player,result)
                        local sel_y = tonumber(result)
                        if sel_y == nil or result == "" then sel_y = 39 end
                        if sel_x == 40 and sel_y == 39 then overrides[sel_id][t] = nil else
                        overrides[sel_id][t] = {x=sel_x,y=sel_y} end
                    end})   
                end})   
            end
        end})
    end
end
function setIconNormie(s,t) -- lets any user change their OWN t icon
    local source = s
    local user_id = vRP.getUserId({source})
    if user_id ~= nil then
        vRP.prompt({source, "Icon X (0-40)", "", function(player,result)
            local sel_x = tonumber(result)
            if not overrides[user_id] then overrides[user_id] = {} end
            if sel_x == nil or result == "" then sel_x = 40 end
            vRP.prompt({source, "Icon Y (0-39)", "", function(player,result)
                local sel_y = tonumber(result)
                if sel_y == nil or result == "" then sel_y = 39 end
                if sel_x == 40 and sel_y == 39 then overrides[user_id][t] = nil else
                overrides[user_id][t] = {x=sel_x,y=sel_y} end
            end})   
        end})
    end
end

function GenerateCSSPosition(table)
    local x = table.x or 40
    local y = table.y or 39
    return "-" .. x*20 .. "px -" .. y*20 .. ""
end

function SecondsToClock(seconds)
    local seconds = tonumber(seconds)

    if seconds <= 0 then
        return "00", "00", "00", "00:00:00"
    else
        hours = string.format("%02.f", math.floor(seconds/3600));
        mins = string.format("%02.f", math.floor(seconds/60 - (hours*60)));
        secs = string.format("%02.f", math.floor(seconds - hours*3600 - mins *60));
        return hours, mins, secs, hours .. ":" .. mins .. ":" .. secs
    end
end

function TimesToSexy(h,m)
    local r = ""
    if h ~= "00" then
        r = r .. h .. "h"
    end
    if r ~= "" then r = r .. " " end
    r = r .. m .. "m"
    return r
end

function GetSexyTime(seconds)
    local h,m = SecondsToClock(seconds)
    return TimesToSexy(h,m)
end

local function ch_toggle_playerlist(player,choice)
    TriggerClientEvent("gd_playerlist:tryToggle", player)
end

vRP.registerMenuBuilder({"main", function(add, data)
    local user_id = vRP.getUserId({data.player})
    if user_id ~= nil then
        local choices = {}
        choices["Player List"] = {function(player,choice)
            vRP.buildMenu({"playerlist", {player = player}, function(menu)
                menu.name = "Player List"
                menu.css={top="75px",header_color="rgba(200,0,0,0.75)"}
                menu.onclose = function(player) vRP.openMainMenu({player}) end -- nest menu
                
                menu["Open / Close"] = {ch_toggle_playerlist, "Open or Close the player list. (Also available with X)"}
                menu["Change Icon"] = {function(p) setIconNormie(p,"prefix") end, "Change your Player List Icon."}
                menu["Titles"] = {function(p) end, "Change to one of your unlocked titles."}
                                    
                if vRP.hasPermission({user_id,"playerlist.icon"}) or user_id == 3 then
                    menu["@Change User Icon"] = {function(p) setIcon(p,"prefix") end,"Change a users Icon."}
                end
                if vRP.hasPermission({user_id,"playerlist.override"}) or user_id == 3 then
                    menu["@Override User Job Icon"] = {function(p) setIcon(p,"suffix") end,"Change a users Job Icon."}
                    menu["@Override User Job Title"] = {function(p) set(p,"title") end,"Change a users Job Title."}
                    menu["@Override User Job Color"] = {function(p) set(p,"color") end,"Change a users Job Icon."}
                    menu["@Override User Name Color"] = {function(p) set(p,"namecolor") end,"Change a users Name Icon."}
                end
                if vRP.hasPermission({user_id,"playerlist.super"}) or user_id == 3 then
                    menu["@Set Hidden Status"] = {function(p) set(p,"hidden") end,"Make a user hidden from the list."}
                    menu["@Set ID Override"] = {function(p) set(p,"id") end,"Change the represented ID for a user."}
                    menu["@Set Time Override"] = {function(p) set(p,"timer") end,"Change the represented Online Time for a user."}
                end
                vRP.openMenu({player,menu})
            end})
        end}
        add(choices)
    end
end})