RegisterServerEvent("gd_jobs_helicopter:tryStartJob")
AddEventHandler("gd_jobs_helicopter:tryStartJob", function(location)
     -- Do all the shit about asking if energy is enough etc
    print(tostring(location))
    TriggerClientEvent("gd_jobs_helicopter:startJob", source, location, 1)
end)

RegisterServerEvent("gd_jobs_helicopter:finishJob")
AddEventHandler("gd_jobs_helicopter:finishJob", function(distance, payment, tier)
     -- Give money based on distance
    print("Distance: "..distance)
    local money = math.floor(distance * payment)
    TriggerClientEvent("chatMessage", source, "^0Received ^2$" .. money)
    -- give xp and whatever
    TriggerClientEvent("chatMessage", source, "^0Earned ^185 xp")
end)

RegisterServerEvent("gd_jobs_helicopter:pickupJob")
AddEventHandler("gd_jobs_helicopter:pickupJob", function(distance, payment, tier)
     -- Give money based on distance
    print("Distance: "..distance)
    local money = math.floor(distance * payment)
    TriggerClientEvent("chatMessage", source, "^0Received ^2$" .. money)
    -- give xp and whatever
    TriggerClientEvent("chatMessage", source, "^0Earned ^185 xp")
end)

RegisterServerEvent("log")
AddEventHandler("log", function(log)
     -- Give money based on distance
    print("Logging: "..log)
end)

AddEventHandler("chatMessage", function(source, name, msg)
    if msg:sub(1,2) == "/p" then
		TriggerClientEvent("Event",source, msg:sub(4))
		CancelEvent()
	end 
end)