--[[
      ▄▌█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█ █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
   ▄▄██▌█  Constructed for Transport Tycoon  █ █   Web http://glitchdetector.net    █
▄▄▄▌▐██▌█              <3 by glitchdetector  █ █  Discord http://discord.gg/fs6bPfu █
███████▌█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█ █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
▀(@)▀▀▀▀▀▀▀(@)(@)▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀(@)▀▀▀▀▀▀▀▀▀ ▀▀▀▀▀▀(@)(@)▀▀▀▀▀▀▀▀▀▀▀▀▀(@)(@)▀▀▀▀▀▀▀
]] 

client_scripts {
    'client/Tunnel.lua', -- vrp tunnel
    'shared/main.lua',
    'client/main.lua'
}

server_scripts {
    '@vrp/lib/utils.lua',
    'shared/main.lua',
    'server/main.lua'
}