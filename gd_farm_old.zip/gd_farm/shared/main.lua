--[[
      ▄▌█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
   ▄▄██▌█  Constructed for Transport Tycoon  █
▄▄▄▌▐██▌█              <3 by glitchdetector  █
███████▌█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
▀(@)▀▀▀▀▀▀▀(@)(@)▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀(@)▀▀▀▀▀▀▀▀▀
]]

Citizen.CreateThread(function()
    print("gd_farm/shared/main.lua init")
--    while true do
--        Citizen.Wait(5)  
--    end
end)