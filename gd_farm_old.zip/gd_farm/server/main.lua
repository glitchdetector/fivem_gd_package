--[[
      ▄▌█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
   ▄▄██▌█  Constructed for Transport Tycoon  █
▄▄▄▌▐██▌█              <3 by glitchdetector  █
███████▌█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
▀(@)▀▀▀▀▀▀▀(@)(@)▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀(@)▀▀▀▀▀▀▀▀▀
]]


local Proxy = module("vrp", "lib/Proxy")
local Tunnel = module("vrp", "lib/Tunnel")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","gd_farm")

vRP.defAptitudeGroup({"farming", "Farming"})
vRP.defAptitude({"farming", "farming", "Farming", 0, 500})

Citizen.CreateThread(function()
    print("gd_farm/server/main.lua init")
--    while true do
--        Citizen.Wait(5)  
--    end
end)

--"gd_farm:drop_material", cargo, amount, vec3(pos)
RegisterServerEvent("gd_farm:drop_material")
AddEventHandler("gd_farm:drop_material", function(cargo, amount, pos)
    TriggerClientEvent("gd_farm:create_material", source, cargo, amount, pos)
end)

-- a player is requesting to start the farming job
RegisterServerEvent("gd_farm:request_job_start")
AddEventHandler("gd_farm:request_job_start", function()
    local source = source
    local user_id = vRP.getUserId({source})
    if vRP.hasPermission({user_id, "farmer.job"}) then
        TriggerClientEvent("gd_farm:start_job", source)
    else
        TriggerClientEvent("gd_farm:notify", source, "~r~You're not a farmer")
    end
end)

local FARM_ITEM_VALUES = {
    ["grain"] = 0.04, -- 40 000 = 1600
    ["bales"] = 400, -- 8 (40 000 grain) = 3200
    ["grass"] = 0.06, -- 40 000 = 2400
    
    ["corn"] = 0, -- not implemented not gonna pay for
    ["oranges"] = 0, -- not implemented not gonna pay for
    ["peaches"] = 0, -- not implemented not gonna pay for
    ["tomatoes"] = 0, -- not implemented not gonna pay for
    ["watermelons"] = 0, -- not implemented not gonna pay for
    ["strawberries"] = 0, -- not implemented not gonna pay for
    ["fertilizer"] = 0, -- not implemented not gonna pay for
    ["seeds"] = 0, -- not implemented not gonna pay for
    ["manure"] = 0, -- not implemented not gonna pay for
    ["livestock"] = 0, -- not implemented not gonna pay for
    ["weed"] = 0, -- not implemented not gonna pay for
    ["grapes"] = 0, -- not implemented not gonna pay for
}

RegisterServerEvent("gd_farm:sell_material")
AddEventHandler("gd_farm:sell_material", function(cargo, amount)
    local source = source
    local user_id = vRP.getUserId({source})
    if user_id ~= nil then
        local pay = math.ceil(FARM_ITEM_VALUES[cargo] * amount)
        local exp = math.ceil(pay / 200)
        vRP.giveMoney({user_id, pay})
        vRP.varyExp({user_id, "farming", "farming", exp})
        local text = "~y~Sales report:~n~~w~" .. amount .. " " .. cargo .. "~n~Total: ~g~$" .. pay
        TriggerClientEvent("gd_farm:notify", source, text)
    else
        print("[gd_farm ERROR]: A user_id was not retrieved, might be caused by the vRP ID error!")
        TriggerClientEvent("gd_farm:notify", source, "An unexpected error occured, you will not be credited for your sale.")
    end
end)