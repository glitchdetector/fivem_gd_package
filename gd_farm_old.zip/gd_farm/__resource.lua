--[[
      ▄▌█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█ █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
   ▄▄██▌█  Constructed for Transport Tycoon  █ █   Web http://glitchdetector.net    █
▄▄▄▌▐██▌█              <3 by glitchdetector  █ █  Discord http://discord.gg/fs6bPfu █
███████▌█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█ █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
▀(@)▀▀▀▀▀▀▀(@)(@)▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀(@)▀▀▀▀▀▀▀▀▀ ▀▀▀▀▀▀(@)(@)▀▀▀▀▀▀▀▀▀▀▀▀▀(@)(@)▀▀▀▀▀▀▀
]] 

client_scripts {
    'client/main.lua',
    'shared/main.lua'
}
server_scripts {
    '@vrp/lib/utils.lua',
    'server/main.lua',
    'shared/main.lua'
}