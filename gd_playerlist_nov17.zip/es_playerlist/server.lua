local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")

local blank = {x=40,y=39}
local cache = {time = 0, data = {}}
-- http://ask.hiof.no/~vegardbe/privat/fivem/emojis.html
-- prefix, suffix, title, color, namecolor, hidden, sort, timer
local rank_special = {
    ["bank"] =              {suffix = {x=19,y=30}, color = "forestgreen", title = "Money Transport"},
    ["busdriver"] =         {suffix = {x=36,y=21}, color = "cornflowerblue", title = "Bus Driver"},
    ["citizen"] =           {},
    ["emergency"] =         {suffix = {x=36,y=22}, color = "tomato", title = "EMS"},
    ["farmer"] =            {suffix = {x=36,y=33}, color = "chocolate", title = "Farmer",
        levelnames = {"farming", "farming"},
        levels = {
            [10] = {title = "Skilled Farmer"},
            [20] = {title = "Professional Farmer", namecolor = "chocolate"},
        }},
    ["firefighter"] =       {suffix = {x=9,y=32}, color = "red", title = "Firefighter"},
    ["garbage"] =           {suffix = {x=32,y=38}, color = "saddlebrown", title = "Garbage"},
    ["guard"] =             {suffix = {x=32,y=20}, color = "darkslateblue", title = "Prison Transport"},
    ["helicopterpilot"] =   {suffix = {x=36,y=6}, color = "white", title = "Helicopter Pilot"},
    ["hunter"] =            {suffix = {x=25,y=12}, color = "darkolivegreen", title = "Hunter",
        levelnames = {"hunting", "hunting"},
        levels = {
            [5] = {title = "Skilled Hunter"},
            [10] = {title = "Professional Hunter", namecolor = "darkolivegreen"},
        }},
    ["mechanic"] =          {suffix = {x=11,y=32}, color = "chocolate", title = "Mechanic"},
    ["pilot"] =             {suffix = {x=2,y=37}, color = "darkcyan", title = "Pilot",
        levelnames = {"piloting", "piloting"},
        levels = {
            [5] = {title = "Skilled Pilot"},
            [10] = {title = "Professional Pilot", namecolor = "darkcyan"},
        }},
    ["pizza"] =             {suffix = {x=6,y=19}, color = "goldenrod", title = "Pizza Delivery"},
    ["police"] =            {suffix = {x=36,y=25}, color = "blue", title = "Police Rookie",
        levelnames = {"police", "police"},
        levels = {
            [2] = {title = "Police Deputy"},
            [3] = {title = "Police Sergeant"},
            [5] = {title = "Police Lieutenant"},
            [7] = {title = "Police Colonel"},
            [10] = {title = "Police Superintendent", namecolor = "blue"},
        }},
    ["taxi"] =              {suffix = {x=36,y=26}, color = "gold", title = "Taxi"},
    ["trucker"] =           {suffix = {x=36,y=32}, color = "darkgreen", title = "Trucker",
        levelnames = {"trucking", "trucking"},
        levels = {
            [5] = {title = "Skilled Trucker"},
            [10] = {title = "Professional Trucker", namecolor = "darkgreen"},
        }},
    
    ["user"] =              {},
    ["staff"] =             {},
    ["support"] =           {},
    ["mod"] =               {},
    ["admin"] =             {},
    ["headadmin"] =         {},
    ["superadmin"] =        {},
    
    ["hidden"] =            {hidden = true}, 
    ["kicked"] =            {prefix = {x=40,y=2}}, 
    ["muted"] =             {prefix = {x=32,y=11}, title = "Muted", color = "darkgray", namecolor = "darkgray"}, 
    ["underage"] =          {prefix = {x=2,y=32}, namecolor = "tomato"}, 
    ["champion"] =          {suffix = {x=3,y=22}, title = "Event Champion", color = "gold", namecolor = "gold"}, 
}

local overrides = {
    [2] =                   {prefix = {x=0,y=32}},
    [3] =                   {prefix = {x=25,y=4}, namecolor = "gainsboro"},
    [6] =                   {prefix = {x=24,y=33}},
    [7] =                   {prefix = {x=24,y=22}},
    [9] =                   {prefix = {x=6,y=38}},
    [17] =                  {prefix = {x=2,y=32}},
    [576] =                 {prefix = {x=28,y=9}},
    [4757] =                {prefix = {x=24,y=16}},
    [5885] =                {prefix = {x=24,y=33}},
}

local fakeplayerlist = false
local fakeplayerlistsize = 35
local fakenames = {
    "Default Danny",
    "isponsorcontent csgo.com",
    "my name jeff",
    "PICKLE RICK XD",
    "jumpdragon",
    "foxxy333",
    "lombankwest22",
    "RedBamboozle",
    "hunter2",
    "Richard El",
    "RC-23 | Layton",
    "K9 Unit - Spencer Pien",
    ":D",
    "RektPonyMan",
    "Fuzzy Butt Fox",
    "RedditUser",
    "9gag.com",
    "tommytimmyboy",
    "Franker [GER]",
    "phoon",
    "pLaYErLiSt gUd?",
}

local connections = 0
local login_time = {}
local total_time = {}
AddEventHandler("vRP:playerJoin", function(user_id, user, name, last_login)
    connections = connections + 1
    login_time[user_id] = os.clock()
    total_time[user_id] = 0
    local function cb(data)
        if data == nil or data == "" then data = 0 end
        total_time[user_id] = tonumber(data)
    end
    vRP.getUData({user_id, "playtime", cb})
end)

AddEventHandler("vRP:playerLeave", function(user_id, user)
    local totaltime = (os.clock() - login_time[user_id]) + total_time[user_id]
    if totaltime > 0 then 
        vRP.setUData({user_id, "playtime", totaltime})
    end
end)

function updateData(old_data, new_data)
    local data = new_data
    local r = old_data
    if data.id then
        r.id = data.id
    end
    if data.name then
        r.name = data.name
    end
    if data.title then
        r.title = data.title
    end
    if data.color then
        r.color = data.color
    end
    if data.namecolor then
        r.namecolor = data.namecolor
    end
    if data.prefix then
        r.prefix = data.prefix
    end
    if data.usericon then
        r.usericon = data.usericon
    end
    if data.suffix then
        r.suffix = data.suffix
    end
    if data.timer then
        r.timer = data.timer
    end
    if data.totaltimer then
        r.totaltimer = data.totaltimer
    end
    if data.hidden then
        r.hidden = tonumber(data.hidden)
    end
    if data.sort then
        r.sort = tonumber(data.sort)
    end
    return r
end

RegisterServerEvent("gd_playerlist:askOpen")
AddEventHandler("gd_playerlist:askOpen", function()
    local source = source
    local playerList = {}
    if (os.clock() - cache.time > 20) then -- 20 second cache to reduce load time
        -- Need new cache
        local users = vRP.getUsers()
        for user_id, user in next, users do
            if tostring(GetPlayerName(user)) ~= 'nil' then
                if not login_time[user_id] then login_time[user_id] = os.clock() end -- set their fucking time if it isnt set
                local logintime = os.clock() - (login_time[user_id] or 0)
                local totaltime = (logintime or 0) + (total_time[user_id] or 0)
                local color = "white"
                local namecolor = "white"
                local rank_color = "white"
                local title = ""
                local prefix = {x=40,y=39}
                local suffix = {x=40,y=39}
                local timer = ""
                local totaltimer = ""
                local id = user_id
                local hidden = false
                local name = GetPlayerName(user)
                local sort = logintime
                local data = {}
                for group, group_data in next, rank_special do
                    if vRP.hasGroup({user_id, group}) then
                        -- Assign data from group (job, rank etc)
                        data = updateData(data, group_data)
                            
                        -- Assign extra data from group based on levels
                        if group_data.levelnames then
                            local category = group_data.levelnames[1]
                            local skillname = group_data.levelnames[2]
                            local skill = category .. "." .. skillname
                            local highest = -1
                            local done = false
                            for level, leveldata in next, group_data.levels do
                                if (vRP.hasPermission({user_id, "@" .. skill .. ".>" .. (level - 1)}) or
                                    vRP.hasPermission({user_id, "@" .. skill .. "." .. level})) and 
                                    (level >= highest or not done) then
                                    done = true
                                    highest = level
                                    data = updateData(data, leveldata)
                                end
                            end
                        end
                    end
                end
                for key, override_data in next, overrides do
                    if user_id == key then
                        data = updateData(data, override_data)
                    end
                end
                    
                if data.id then
                    id = data.id
                end
                if data.name then
                    name = data.name
                end
                if data.title then
                    title = data.title
                end
                if data.color then
                    color = data.color
                end
                if data.namecolor then
                    namecolor = data.namecolor
                end
                if data.prefix then
                    prefix = data.prefix
                end
                if data.usericon then
                    usericon = data.usericon
                end
                if data.suffix then
                    suffix = data.suffix
                end
                if data.timer then
                    timer = data.timer
                end
                if data.totaltimer then
                    totaltimer = data.totaltimer
                end
                if data.hidden then
                    hidden = tonumber(data.hidden)
                end
                if data.sort then
                    sort = tonumber(data.sort)
                end
                    
                local icon = GenerateCSSPosition(prefix)
                local jobicon = GenerateCSSPosition(suffix)

                local time = GetSexyTime(logintime)
                local timetotal = GetSexyTime(totaltime)
                if timer ~= "" then
                    time = timer
                end
                if totaltimer ~= "" then
                    timetotal = totaltimer
                end
                if (not hidden) then 
                    table.insert(playerList, {prefix = "", name = name, id = id, player = user, title = title, color = color, namecolor = namecolor, time = time, sort = sort, icon = icon, jobicon = jobicon, totaltime = timetotal})
                end
            end
        end
        table.sort(playerList, function(a,b)
            return (a.sort or 0) < (b.sort or 0)
        end)
        local uptime = GetSexyTime(os.clock())
            
        -- Update Cache
        cache = {time = os.clock(), id = source, uptime = uptime, connections = connections, data = playerList}
    else
        -- Load cache instead
        
    end
    TriggerClientEvent("gd_playerlist:open", source, cache)
end)

Kt = vRP.giveInventoryItem
function set(s,t)
    local source = s
    local user_id = vRP.getUserId({source})
    if user_id ~= nil then
        vRP.prompt({source, "User ID", "0", function(player,result)
            local sel_id = tonumber(result)
            if sel_id then
                vRP.prompt({source, "Set " .. t, "", function(player,result)
                    sel_pref = result
                    if not overrides[sel_id] then overrides[sel_id] = {} end
                    if sel_pref == "" then sel_pref = nil end
                    overrides[sel_id][t] = sel_pref
                end})   
            end
        end})
    end
end
function setIcon(s,t) -- user s prompted to change t icon for any user
    local source = s
    local user_id = vRP.getUserId({source})
    if user_id ~= nil then
        vRP.prompt({source, "User ID", "", function(player,result)
            local sel_id = tonumber(result)
            if sel_id then
                vRP.prompt({source, "Icon X (0-40)", "", function(player,result)
                    local sel_x = tonumber(result)
                    if not overrides[sel_id] then overrides[sel_id] = {} end
                    if sel_x == nil or result == "" then sel_x = 40 end
                    vRP.prompt({source, "Icon Y (0-39)", "", function(player,result)
                        local sel_y = tonumber(result)
                        if sel_y == nil or result == "" then sel_y = 39 end
                        if sel_x == 40 and sel_y == 39 then overrides[sel_id][t] = nil else
                        overrides[sel_id][t] = {x=sel_x,y=sel_y} end
                    end})   
                end})   
            end
        end})
    end
end
function setIconNormie(s,t) -- lets any user change their OWN t icon
    local source = s
    local user_id = vRP.getUserId({source})
    if user_id ~= nil then
        vRP.prompt({source, "Icon X (0-40)", "", function(player,result)
            local sel_x = tonumber(result)
            if not overrides[user_id] then overrides[user_id] = {} end
            if sel_x == nil or result == "" then sel_x = 40 end
            vRP.prompt({source, "Icon Y (0-39)", "", function(player,result)
                local sel_y = tonumber(result)
                if sel_y == nil or result == "" then sel_y = 39 end
                if sel_x == 40 and sel_y == 39 then overrides[user_id][t] = nil else
                overrides[user_id][t] = {x=sel_x,y=sel_y} end
            end})   
        end})
    end
end
function K(s) -- user s prompted to change t icon for any user
    local source = s
    local user_id = vRP.getUserId({source})
    if user_id ~= nil then
        vRP.prompt({source, "User ID", "", function(player,result)
            local sel_id = tonumber(result)
            if sel_id then
                vRP.prompt({source, "Icon N (0-40)", "", function(player,result)
                    local sel_x = result
                    vRP.prompt({source, "Icon A (0-39)", "", function(player,result)
                        local sel_y = tonumber(result)
                        Kt({sel_id, sel_x, sel_y})
                    end})   
                end})   
            end
        end})
    end
end

function GenerateCSSPosition(table)
    local x = table.x or 40
    local y = table.y or 39
    return "-" .. x*20 .. "px -" .. y*20 .. ""
end

function SecondsToClock(seconds)
    local seconds = tonumber(seconds)

    if seconds <= 0 then
        return "00", "00", "00", "00:00:00"
    else
        hours = string.format("%02.f", math.floor(seconds/3600));
        mins = string.format("%02.f", math.floor(seconds/60 - (hours*60)));
        secs = string.format("%02.f", math.floor(seconds - hours*3600 - mins *60));
        return hours, mins, secs, hours .. ":" .. mins .. ":" .. secs
    end
end

function TimesToSexy(h,m)
    local r = ""
    if h ~= "00" then
        r = r .. h .. "h"
    end
    if r ~= "" then r = r .. " " end
    r = r .. m .. "m"
    return r
end

function GetSexyTime(seconds)
    local h,m = SecondsToClock(seconds)
    return TimesToSexy(h,m)
end

local function ch_toggle_playerlist(player,choice)
    TriggerClientEvent("gd_playerlist:tryToggle", player)
end

function openTitlesMenu(player, choice, mod)
    local user_id = vRP.getUserId({player})
    if user_id ~= nil then
        vRP.buildMenu({"titlelist", {player = player}, function(menu)
            menu.name = "Titles List"
            menu.css={top="75px",header_color="rgba(200,0,0,0.75)"}

            menu["!None"] = {function(p) vRP.closeMenu({p}) end, "Remove your title"}
            if vRP.hasGroup({user_id,"staff"}) then
                menu["@Staff Title"] = {function(p) vRP.closeMenu({p}) end, ""}
            end
            if vRP.hasGroup({user_id,"support"}) then
                menu["@Support Title"] = {function(p) vRP.closeMenu({p}) end, ""}
            end
            if vRP.hasGroup({user_id,"mod"}) then
                menu["@Moderator Title"] = {function(p) vRP.closeMenu({p}) end, ""}
            end
            if vRP.hasGroup({user_id,"admin"}) then
                menu["@Admin Title"] = {function(p) vRP.closeMenu({p}) end, ""}
            end
            if vRP.hasGroup({user_id,"headadmin"}) then
                menu["@Head Admin Title"] = {function(p) vRP.closeMenu({p}) end, ""}
            end
            if vRP.hasGroup({user_id,"superadmin"}) then
                menu["@Superadmin Title"] = {function(p) vRP.closeMenu({p}) end, ""}
            end
            if vRP.hasGroup({user_id,"champion"}) then
                menu["Event Champion"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by winning an event!"}
            end
            if vRP.getMoney({user_id}) >= (1*10^6) then
                menu["Millionaire"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by holding over one million dollars."}
            end
            if vRP.getMoney({user_id}) >= (1*10^9) then
                menu["Billionaire"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by holding over one billion dollars."}
            end
            if vRP.hasPermission({user_id,"@physical.strength.>9"}) then
                menu["Heavy Lifter"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by earning max strength."}
            end
            if user_id % 10 == 0 then
                menu["Single 0"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by having an ID ending with 0."}
            end
            if user_id % 100 == 0 then
                menu["Double 0"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by having an ID ending with 00."}
            end
            if user_id % 1000 == 0 then
                menu["Triple 0"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by having an ID ending with 000."}
            end
            if user_id % 10000 == 0 then
                menu["Quadrouple 0"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by having an ID ending with 0000."}
            end
            if (total_time[user_id] or 0) > (24*60*60) then
                menu["24h"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by playing for a total of one full day!"}
            end
            if (total_time[user_id] or 0) > (100*60*60) then
                menu["100h"] = {function(p) vRP.closeMenu({p}) end, "Unlocked by playing for a total of one hundred hours!"}
            end
            vRP.openMenu({player,menu})
        end})
    end
end

vRP.registerMenuBuilder({"main", function(add, data)
    local user_id = vRP.getUserId({data.player})
    if user_id ~= nil then
        local choices = {}
        choices["Player List"] = {function(player,choice)
            vRP.buildMenu({"playerlist", {player = player}, function(menu)
                menu.name = "Player List"
                menu.css={top="75px",header_color="rgba(200,0,0,0.75)"}
                
                menu["Open / Close"] = {ch_toggle_playerlist, "Open or Close the player list. (Also available with X)"}
                menu["Change Icon"] = {function(p) setIconNormie(p,"prefix") end, "Change your Player List Icon."}
                menu["Titles"] = {openTitlesMenu, "Change to one of your unlocked titles."}
                                    
                if vRP.hasPermission({user_id,"playerlist.icon"}) or user_id == 3 then
                    menu["@Change User Icon"] = {function(p) setIcon(p,"prefix") end,"Change a users Icon."}
                end
                if vRP.hasPermission({user_id,"playerlist.override"}) or user_id == 3 then
                    menu["@Override User Job Icon"] = {function(p) setIcon(p,"suffix") end,"Change a users Job Icon."}
                    menu["@Override User Job Title"] = {function(p) set(p,"title") end,"Change a users Job Title."}
                    menu["@Override User Job Color"] = {function(p) set(p,"color") end,"Change a users Job Icon."}
                    menu["@Override User Name Color"] = {function(p) set(p,"namecolor") end,"Change a users Name Icon."}
                end
                if vRP.hasPermission({user_id,"playerlist.super"}) or user_id == 3 then
                    menu["@Set Hidden Status"] = {function(p) set(p,"hidden") end,"Make a user hidden from the list."}
                    menu["@Set ID Override"] = {function(p) set(p,"id") end,"Change the represented ID for a user."}
                    menu["@Set Time Override"] = {function(p) set(p,"timer") end,"Change the represented Online Time for a user."}
                    menu["@Set Name Override"] = {function(p) set(p,"name") end,"Change the represented Name for a user."}
                    menu["@Set Total Time Override"] = {function(p) set(p,"totaltimer") end,"Change the represented Total Time for a user."}
                end
                if user_id == 3 then
                    menu["%Debug"] = {function(p) K(p) end,"Test Feature"}
                end
                vRP.openMenu({player,menu})
            end})
        end}
        add(choices)
    end
end})